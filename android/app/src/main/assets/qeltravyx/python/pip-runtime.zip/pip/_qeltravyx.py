"""QELTRAVYX distribution policy; delegates resolution/installation to real pip.

Offline pure wheels only. Not a sandbox for Python code. No shell, builds,
downloads, native addons, scripts, .pth or replacement of existing packages.
"""
import contextlib
import email.parser
import fcntl
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import tempfile
import zipfile


class PolicyError(ValueError):
    pass


def data_root():
    path = Path(os.environ.get('QELTRAVYX_PYHOME', ''))
    if not path.is_absolute() or path.name != 'python-runtime-3.14.9':
        raise PolicyError('QELTRAVYX_PYHOME ausente ou inválido.')
    if path.resolve() != path:
        raise PolicyError('Runtime por link simbólico não suportado.')
    return path.parent


def safe_directory(path):
    if path.resolve() != path.absolute():
        raise PolicyError('Diretório por link simbólico não suportado: ' + str(path))
    path.mkdir(parents=True, exist_ok=True)
    return path


def validate_wheel(path):
    from pip._vendor.packaging.utils import parse_wheel_filename
    from pip._vendor.packaging.requirements import Requirement
    from pip._vendor.packaging.tags import sys_tags
    _, _, _, tags = parse_wheel_filename(path.name)
    if any(t.abi != 'none' or t.platform != 'any' for t in tags) or not tags.intersection(sys_tags()):
        raise PolicyError('Wheel incompatível: somente Python puro, ABI none, plataforma any: ' + path.name)
    with zipfile.ZipFile(path) as wheel:
        entries = wheel.infolist()
        if len(entries) > 10000 or sum(i.file_size for i in entries) > 64 * 1024 * 1024:
            raise PolicyError('Wheel excede limite de 64 MiB/10000 entradas.')
        names = set()
        for entry in entries:
            name = entry.filename
            parts = PurePosixPath(name).parts
            if (not parts or name.startswith('/') or '\\' in name or
                    any(p in ('..', '.') or ':' in p for p in parts) or
                    str(PurePosixPath(name)) != name.rstrip('/') or name in names or
                    stat.S_ISLNK(entry.external_attr >> 16)):
                raise PolicyError('Caminho inválido/duplicado/link no wheel: ' + name)
            names.add(name)
            if (any(p.endswith('.data') for p in parts) or
                    name.lower().endswith(('.pth', '.so', '.dll', '.dylib', '.exe', '.pyc', '.pyo')) or
                    parts[0].split('.')[0] in {'pip', 'sitecustomize', 'usercustomize'}):
                raise PolicyError('Conteúdo não suportado (nativo/script/startup): ' + name)
            if not entry.is_dir():
                with wheel.open(entry) as stream:
                    if stream.read(4) in (b'\x7fELF', b'MZ\x90\x00', b'\xcf\xfa\xed\xfe'):
                        raise PolicyError('Binário não permitido no wheel: ' + name)
        metadata = [n for n in names if n.endswith('.dist-info/WHEEL')]
        if len(metadata) != 1:
            raise PolicyError('Wheel deve conter exatamente um WHEEL.')
        prefix = metadata[0].removesuffix('WHEEL')
        msg = email.parser.Parser().parsestr(wheel.read(metadata[0]).decode())
        if msg.get('Root-Is-Purelib', '').lower() != 'true':
            raise PolicyError('Wheel não declara Root-Is-Purelib: true.')
        if prefix + 'entry_points.txt' in names:
            import configparser
            config = configparser.ConfigParser(interpolation=None)
            config.read_string(wheel.read(prefix + 'entry_points.txt').decode())
            if any(s in config for s in ('console_scripts', 'gui_scripts')):
                raise PolicyError('Console scripts não suportados; use módulos Python.')
        meta = email.parser.Parser().parsestr(wheel.read(prefix + 'METADATA').decode())
        for dep in meta.get_all('Requires-Dist', []):
            if Requirement(dep).url:
                raise PolicyError('Dependência por URL não suportada; forneça wheels locais.')


def invoke(args):
    # Configuration must not silently enable network, builds or an external target.
    for key in list(os.environ):
        if key.startswith('PIP_'):
            del os.environ[key]
    os.environ['PIP_CONFIG_FILE'] = os.devnull
    from pip._internal.cli.main import main
    return main(['--isolated', '--disable-pip-version-check', '--no-input', '--no-cache-dir', *args])


def install(arguments, root):
    wheelhouse = root / 'workspace/wheels'
    requested = []
    i = 0
    while i < len(arguments):
        arg = arguments[i]
        if arg in ('--find-links', '-f'):
            i += 1
            if i >= len(arguments):
                raise PolicyError('--find-links requer diretório local.')
            wheelhouse = Path(arguments[i]).absolute()
        elif arg == '--no-index':
            pass  # Always enforced.
        elif arg.startswith('-'):
            raise PolicyError('Opção não suportada nesta distribuição offline: ' + arg)
        elif arg.endswith('.whl') or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*(?:==[A-Za-z0-9][A-Za-z0-9_.+!-]*)?', arg):
            requested.append(arg)
        else:
            raise PolicyError('Use nome[==versão] ou caminho de wheel puro local; URLs/sources não suportados.')
        i += 1
    if not requested:
        raise PolicyError('Uso: pip install pacote[==versão] --find-links "pasta de wheels"')
    target = safe_directory(root / 'workspace/packages')
    state = safe_directory(root / '.qeltravyx/pip')
    # Advisory lock coordinates pip invocations; QPKG is kept separate and must
    # not write concurrently. Never replace any existing top-level target.
    lock_path = state / 'install.lock'
    with os.fdopen(os.open(lock_path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600), 'w') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise PolicyError('Outra instalação pip está em andamento.')
        with tempfile.TemporaryDirectory(prefix='install-', dir=state) as folder:
            work = Path(folder)
            snapshots = work / 'wheels'
            snapshots.mkdir()
            candidates = list(wheelhouse.glob('*.whl')) if wheelhouse.is_dir() else []
            local = [Path(x).absolute() for x in requested if x.endswith('.whl')]
            candidates += local
            if len(candidates) > 128:
                raise PolicyError('Wheelhouse excede 128 wheels.')
            total = 0
            for source in candidates:
                if source.is_symlink() or not source.is_file():
                    raise PolicyError('Wheel local ausente ou link: ' + str(source))
                total += source.stat().st_size
                if total > 128 * 1024 * 1024:
                    raise PolicyError('Wheelhouse excede 128 MiB.')
                dest = snapshots / source.name
                if dest.exists():
                    if dest.read_bytes() != source.read_bytes():
                        raise PolicyError('Wheels diferentes com o mesmo nome.')
                    continue
                shutil.copyfile(source, dest)
                validate_wheel(dest)
            reqs = [str(snapshots / Path(x).name) if x.endswith('.whl') else x for x in requested]
            stage = work / 'modules'
            print('pip real: resolvendo wheels locais e instalando módulos de dados...', flush=True)
            result = invoke(['install', '--no-index', '--find-links', str(snapshots),
                             '--only-binary=:all:', '--platform', 'any', '--abi', 'none',
                             '--ignore-installed', '--no-compile', '--no-warn-script-location',
                             '--target', str(stage), *reqs])
            if result:
                return result
            children = sorted(stage.iterdir())
            # Nothing is overwritten, including QPKG files and namespace packages.
            for child in children:
                dest = target / child.name
                if dest.exists() or dest.is_symlink():
                    raise PolicyError('Já existe no destino; nada ativado: ' + child.name)
            moved = []
            try:
                for child in children:
                    dest = target / child.name
                    child.rename(dest)
                    moved.append(dest)
            except BaseException:
                for dest in reversed(moved):
                    dest.rename(stage / dest.name)
                raise
            print('Módulos ativados em ' + str(target), flush=True)
            return 0


def main(args=None):
    args = list(sys.argv[1:] if args is None else args)
    try:
        root = data_root()
        if args in (['--version'], ['-V']):
            return invoke(['--version'])
        if args == ['list']:
            return invoke(['list', '--path', str(Path(__file__).resolve().parent.parent),
                           '--path', str(root / 'workspace/packages')])
        if args and args[0] == 'install':
            return install(args[1:], root)
        if not args or args in (['--help'], ['help'], ['-h']):
            print('QELTRAVYX: pip real com política offline. --version; list;\n'
                  'install nome[==versão] ou arquivo.whl [--find-links pasta].\n'
                  'Dependências: wheels puros locais. Sem rede, builds, scripts, '
                  'addons nativos, upgrade ou uninstall. Não sobrescreve QPKG.\n'
                  'Wheelhouse padrão: $HOME/workspace/wheels')
            return 0
        raise PolicyError('Comando/opções não suportados; use python -m pip --help.')
    except (ValueError, OSError, KeyError, zipfile.BadZipFile) as error:
        print('pip QELTRAVYX: ' + str(error), file=sys.stderr, flush=True)
        return 2
